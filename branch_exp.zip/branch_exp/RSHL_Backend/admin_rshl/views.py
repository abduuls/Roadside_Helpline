from django.shortcuts import render,redirect
from . import forms,functions,models

from django.contrib.auth import authenticate, login, logout

import json

from django.contrib.auth.models import User
from django.utils.safestring import mark_safe
from django.http import JsonResponse,HttpResponseBadRequest ,HttpRequest
from django.views.decorators.csrf import csrf_exempt

# Create your views here.
def get_json(receive):
    return json.loads(HttpRequest.read(self=receive).decode('utf-8'))

# Client API

# -----------User Login API
@csrf_exempt
def client_login(request):
    if request.method == 'POST':
        return_dict = {
            'error':False,
            'error_detail':'',
            'token':''
        }
        auth = get_json(receive=request)
        print(auth)
        try:
            username = auth['username']
            password = auth['password']
        except Exception as e:
            return_dict['error']=True
            return_dict['error_detail']=f'{e}'
            return JsonResponse(return_dict)
        
        user = models.AppUser.objects.filter(username=username)

        if user.exists():
            w_user = user.get()
            if w_user.check_pass(password):
                return_dict['token'] = f'{w_user.token}'
                return JsonResponse(return_dict)
            else:
                return_dict['error']=True
                return_dict['error_detail']=f'Error: Wrong Password!'
                return JsonResponse(return_dict)    
        else:
            return_dict['error']=True
            return_dict['error_detail']=f'Error: Signup First, User doesn\'t Exists.'
            return JsonResponse(return_dict)
    else:    
        return HttpResponseBadRequest()
    
@csrf_exempt
def client_signup(request):
    if request.method == 'POST':
        return_dict = {
            'error':False,
            'error_detail':'',
            'token':''
        }
        auth = get_json(receive=request)
        print(auth)
        try:
            name = auth['name']
            username = auth['username']
            password = auth['password']
            email = auth['email']
            phone = auth['phone']
        except Exception as e:
            return_dict['error']=True
            return_dict['error_detail']=f'{e}'
            return JsonResponse(return_dict)
        
        user = models.Client.objects.filter(username=username)

        if not user.exists():
            user_sign = models.AppUser.objects.create(name=name,
                                                      username=username,
                                                      email=email,
                                                      phone=phone)
            user_sign.create_pass(password)
            user_sign.save()
            default_payment = models.Client_Card.objects.create(
                card_user = user_sign,
                card_number = "0",
                card_cvv = "0",
                card_exp_month = 0,
                card_exp_year = 0,
                card_type = 0 ,
                card_name = "CASH",
                allow_delete = False,
            )
            default_payment.save()
            token = user_sign.token
            return_dict['token'] = token
            return JsonResponse(return_dict)
        else:
            return_dict['error']=True
            return_dict['error_detail']=f'Error: User already Exists.'
            return JsonResponse(return_dict)
    else:    
        return HttpResponseBadRequest()

# -----------Admin Templates Render
def all_logout(request):
    if request.user.is_authenticated:
        logout(request=request)
    return redirect('root')

def all_login(request):
    context = {'error':''}
    if request.user.is_authenticated:
        return redirect('root')
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request=request,username=username,password=password,)
        if user is not None:
            login(request=request,user=user)
            return redirect('root')
        else:
            context['error']='Error: Incorrect Username or Password'
    return render(request, 'auth/login.html', context)

def root_render(request):
    if not request.user.is_authenticated:
        return redirect('auth_custom')
    return render(request, 'home.html')

def vendor_reg(request):
    title = 'Vendor Registration'
    if request.method == 'POST':
        
        username = request.POST['username']
        name = request.POST['name']
        email = request.POST['email']
        password = request.POST['password']
        address = request.POST['address']
        phone = request.POST['phone']
        shop_no = request.POST['shop_no']
        tier = request.POST['tier']

        if not User.objects.filter(username=username).exists():
            # new_vendor = User.objects.create(
            #             username=username,
            #             email=email,
            #             last_name=name,
            #             is_staff=False
            #                                 )
            new_vendor = User.objects.create_user(username=username,email=email,password=password,last_name=name)
            new_vendor_raw = models.Vendor.objects.create(user=new_vendor,address=address,phone=phone,shop_no=shop_no,service_tier=tier).save()
            return redirect('root')     
    form = forms.VendorReg()
    context = {'form':form,'title':title}
    return render(request, 'auth/vendor_form.html',context)