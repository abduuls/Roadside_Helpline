from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
import uuid
import hashlib

# Create your models here.

class Vendor(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    address = models.CharField(max_length=128)
    phone = models.IntegerField()
    shop_no = models.CharField(max_length=128)
    first_sign = models.BooleanField(default=True)
    service_tier = models.SmallIntegerField()

    def __str__(self) -> str:
        return f'{self.name}|{self.created}'

#CLIENT THING
class AppUser(models.Model):
    name = models.CharField(max_length=255,default='NEW USER')
    email = models.CharField(max_length=150, default='null@localhost.local')
    phone = models.CharField(max_length=11)
    username = models.CharField(max_length=128,unique=True)
    token = models.UUIDField(unique=True,default=uuid.uuid4,editable=False)
    password = models.CharField(max_length=512)
    deleted = models.BooleanField(default=False)
    created = models.CharField(max_length=255, default=f'{timezone.datetime.today().isoformat()}')
    update = models.CharField(max_length=255, default=f'{timezone.datetime.today().isoformat()}')

    def check_pass(self, raw_pass):
        hash = hashlib.sha256()
        hash.update(bytes(f'{raw_pass}','utf-8'))
        if hash.hexdigest() == self.password:
            return True
        else:
            return False

    def create_pass(self, raw_pass):
        hash = hashlib.sha256()
        hash.update(bytes(f'{raw_pass}','utf-8'))
        self.password = hash.hexdigest()

    def update_timestamp(self):
        self.created=f'{timezone.datetime.today().isoformat()}'

    def __str__(self) -> str:
        return f'{self.name}|{self.created}'
    
class Client_Card(models.Model):
    card_user = models.ForeignKey(AppUser, on_delete=models.CASCADE)
    card_number = models.CharField(max_length=17)
    card_cvv = models.CharField(max_length=5)
    card_exp_month = models.IntegerField()
    card_exp_year = models.IntegerField()
    card_type = models.SmallIntegerField()
    card_name = models.CharField(max_length=100)
    allow_delete = models.BooleanField(default=False)

    def __str__(self) -> str:
        return f'{self.card_name}|{self.card_number}'