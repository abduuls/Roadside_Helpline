from django import forms
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout,Submit
from django.utils.safestring import mark_safe

class VendorReg(forms.Form):
    choices = [('1','Flat Tyre'),('2','Fuel Refill'),('3','Towing'),('4','Auto Mechanic'),('5','Auto Electrician')]

    username = forms.CharField(label='Username', max_length=100) 
    name = forms.CharField(label='Full Name', max_length=100)
    email = forms.EmailField(label='Email', max_length=100)
    password = forms.CharField(label='Password',widget=forms.PasswordInput(),max_length=40)
    address = forms.CharField(label='Address',max_length=128)
    phone = forms.CharField(label='Phone#',max_length=11,widget=forms.NumberInput())
    shop_no = forms.CharField(label='Shop Number', max_length=20)
    tier = forms.ChoiceField(choices=choices,label='Chose Tier',initial=choices[0],help_text='These Tiers are From tier1 to tier5 respectivebly and Selected Tier incluedes services from previous Tier.')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper(self)
        self.helper.add_input(Submit(name='submit',value='Submit'))
        self.helper.form_method='POST'