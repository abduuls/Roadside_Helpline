from django.urls import path,include
from . import views

urlpatterns = [
    # User API
    path('api/user/login',views.client_login, name='client_login'),
    path('api/user/signup',views.client_signup, name='client_signup'),

    path('',views.root_render, name='root'),
    path('login',views.all_login, name='auth_custom'),
    path('logout', views.all_logout, name='logout_custom'),

    path('vendor/register', views.vendor_reg, name='ventor_rego')
]