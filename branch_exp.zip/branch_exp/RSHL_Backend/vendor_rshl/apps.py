from django.apps import AppConfig


class VendorRshlConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'vendor_rshl'
