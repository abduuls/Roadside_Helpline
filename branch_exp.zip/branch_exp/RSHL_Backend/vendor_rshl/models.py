from django.db import models
from django.utils import timezone
import uuid
import hashlib
from admin_rshl import models as admin_models
from . import models as self_model

# Create your models here.

class HAsset(models.Model):
    vendor_id = models.ForeignKey(admin_models.Vendor ,on_delete=models.CASCADE)
    name = models.CharField(max_length=255,default='NEW USER')
    username = models.CharField(max_length=128,unique=True)
    token = models.UUIDField(unique=True,default=uuid.uuid4,editable=False)
    password = models.CharField(max_length=512)
    deleted = models.BooleanField(default=False)
    created = models.CharField(max_length=255, default=f'{timezone.datetime.today().isoformat()}')
    update = models.CharField(max_length=255, default=f'{timezone.datetime.today().isoformat()}')

    def check_pass(self, raw_pass):
        hash = hashlib.sha256()
        hash.update(bytes(f'{raw_pass}','utf-8'))
        if hash.hexdigest() == self.password:
            return True
        else:
            return False

    def create_pass(self, raw_pass):
        hash = hashlib.sha256()
        hash.update(bytes(f'{raw_pass}','utf-8'))
        self.password = hash.hexdigest()

    def update_timestamp(self):
        self.created=f'{timezone.datetime.today().isoformat()}'

    def __str__(self) -> str:
        return f'{self.name}|{self.created}'


class ServiceLog(models.Model):
    vendor_id = models.ForeignKey(admin_models.Vendor ,on_delete=models.CASCADE)
    user_id = models.ForeignKey(admin_models.AppUser ,on_delete=models.CASCADE)
    rider_id = models.ForeignKey(HAsset , on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now=True)
    location_latitude = models.FloatField()
    location_longitude = models.FloatField()
    finished = models.BooleanField(default=False)
    towing = models.BooleanField(default=False)
    created = models.CharField(max_length=100,default=f'{timezone.now().isoformat()}')
    
    def __str__(self) -> str:
        return f'{self.finished}|{self.created}'
    

class Servicelog_Servicerequired(models.Model):
    service_id = models.ForeignKey(self_model.ServiceLog, on_delete=models.CASCADE)
    service_text = models.CharField(max_length=100)
    service = models.SmallIntegerField()
    
    def __str__(self) -> str:
        return f'{self.service_text}'

class ServiceDoneDetail(models.Model):
    service_id = models.ForeignKey(self_model.ServiceLog, on_delete=models.CASCADE)
    work_done = models.CharField(max_length=100)
    work_cost = models.BigIntegerField()

    def __str__(self) -> str:
        return f'{self.work_done}'
    
class PaymentLog(models.Model):
    service_id = models.ForeignKey(self_model.ServiceLog, on_delete=models.CASCADE)
    total_cost = models.BigIntegerField()
    payment_method = models.SmallIntegerField()
    payment_detail = models.ForeignKey(admin_models.Client_Card,on_delete=models.CASCADE)
    payment_done = models.BooleanField(default=False)
    reciept_sent = models.BooleanField(default=False)

    def __str__(self) -> str:
        return f'{self.payment_done}'