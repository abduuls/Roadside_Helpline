from django.conf import settings as config
from . import models
from admin_rshl import models as admin_model

def job_status(rider,finished,towing):
    rider_check = rider.exist()
    if not rider_check and not finished:
        return 'Pending'
    elif rider_check and not finished:
        x = ''
        if towing:
            x = ', Towing'
        return 'Rider Assigned'+x
    else:
        return 'Job Fullfilled'

def get_customer(customer):
    customer_obj = customer.get()
    return [customer.name,customer.phone]

def service_req(job_obj):
    jobs_avail =  config.VENDOR_TIER_LIST
    return  jobs_avail[models.Servicelog_Servicerequired.objects.filter(service_id=job_obj).get().service]

def job_postprocess(job):
    ret_list = []
    job_objects = job
    for sr,job_object in enumerate(job_objects,1):
        ret_list.append({
            'serial':sr,
            'customer':get_customer(job_object.user_id),
            'service':service_req(job_object),
            'status':job_status(rider=job_object.rider_id,finished=job_object.finished,towing=job_object.towing)
        })
    return ret_list