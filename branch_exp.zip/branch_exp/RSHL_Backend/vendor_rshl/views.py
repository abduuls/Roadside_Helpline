from django.shortcuts import render
from . import forms,functions,models
from django.contrib.auth.models import User
from admin_rshl import models as admin_model

from django.contrib.auth.decorators import login_required

from . import functions

import json

from django.http import JsonResponse,HttpResponseBadRequest ,HttpRequest
from django.views.decorators.csrf import csrf_exempt

# Create your views here.
def get_json(receive):
    return json.loads(HttpRequest.read(self=receive).decode('utf-8'))

# Client API

# -----------User Login API
@csrf_exempt
def rider_login(request):
    if request.method == 'POST':
        return_dict = {
            'error':False,
            'error_detail':'',
            'token':''
        }
        auth = get_json(receive=request)
        print(auth)
        try:
            username = auth['username']
            password = auth['password']
        except Exception as e:
            return_dict['error']=True
            return_dict['error_detail']=f'{e}'
            return JsonResponse(return_dict)
        
        user = models.HAsset.objects.filter(username=username)

        if user.exists():
            w_user = user.get()
            if w_user.check_pass(password):
                return_dict['token'] = f'{w_user.token}'
                return JsonResponse(return_dict)
            else:
                return_dict['error']=True
                return_dict['error_detail']=f'Error: Wrong Password!'
                return JsonResponse(return_dict)    
        else:
            return_dict['error']=True
            return_dict['error_detail']=f'Error: Signup First, User doesn\'t Exists.'
            return JsonResponse(return_dict)
    else:    
        return HttpResponseBadRequest()

### --- Vendor's Job
@login_required()  
def job_view_all(request):
    user = request.user
    user.refresh_from_db()
    vendor = admin_model.Vendor.objects.filter(user=user).get()
    jobs = models.ServiceLog.objects.filter(vendor_id=vendor).all()
    context = {'job':functions.job_postprocess(jobs)}

def def_thing():
    pass