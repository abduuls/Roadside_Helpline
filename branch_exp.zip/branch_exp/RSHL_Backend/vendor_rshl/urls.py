from django.urls import path,include
from . import views



urlpatterns = [
# Rider API
    path('api/rider/login',views.rider_login, name='rider_login'),
]