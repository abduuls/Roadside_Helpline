# Admin:
- vendor management
- user management
- rider management
- service log
- payment log

# Vendor:
- user management
- rider management
- service log
- payment log

# Rider:
