#!/usr/bin/python3

import subprocess
import os
import argparse
import shutil
parser = argparse.ArgumentParser()
parser.add_argument("--create","-c", help="Create DataBase",action="store_true") 
parser.add_argument('--remove','-r', help="Remove DataBase",action="store_true")

args = parser.parse_args()

if args.create:
    subprocess.run(["python", "manage.py", "makemigrations", "admin_rshl", "vendor_rshl"],)
    subprocess.run(["python", "manage.py", "migrate"],)
    print("Created")
elif args.remove:
    try:
        shutil.rmtree("admin_rshl/migrations")
        shutil.rmtree("admin_rshl/__pycache__")
        shutil.rmtree("vendor_rshl/migrations")
        shutil.rmtree("vendor_rshl/__pycache__")
        os.remove("db.sqlite3")
    except:
        pass
    print("Removed")
else:
    print("For Help do -h")