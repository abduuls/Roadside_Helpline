from django.contrib import admin
from .models import AppUser as Client

# Register your models here.

@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    list_display=('name',
                  'username',
                  'token',
                  'deleted')
    list_filter=( 'created',
                  'update')
    ordering=('username',
              'update')