from django.urls import path,include
from . import views

urlpatterns = [
    # User API
    path('api/user/login',views.client_login, name='client_login'),
    path('api/user/signup',views.client_signup, name='client_signup'),
    path('api/user/get/vendors', views.vendors_get, name='vendors_get'),
    path('api/user/get/vendor', views.vendor_get, name='vendor_get'),
    path('api/user/get/orders',views.get_old_orders, name='order_get_list'),
    path('api/user/get/profile',views.get_profile,name='user_get_profile'),
    path('api/user/otp',views.verify_otp_api,name='otp_api'),
    path('api/user/get/services',views.get_services,name='service_populate'),

    path('api/user/get/payments',views.get_payment_methods,name='payment_method_populate'),
    path('api/user/add/payments',views.add_payment_methods,name='payment_method_create'),
    path('api/user/set/payments/default',views.add_payment_methods,name='payment_method_create'),
    
    path('user/otp', views.verify_otp, name='client_verification'),
    path('image/get/<image_name>', views.send_image, name='image_retrive'),


    path('',views.root_render, name='root'),
    path('login',views.all_login, name='auth_custom'),
    path('logout', views.all_logout, name='logout_custom'),

    path('admn/vendor/register', views.vendor_reg, name='vendor_rego'),
    path('admn/vendor/view', views.vendor_view, name='vendor_views'),
    
    # Jobs Urls
    path('admn/jobs/all',views.admin_job_view_all, name='admin_jobs_all'),
    path('admn/jobs/pending',views.admin_job_view_pending, name='admin_jobs_pend'),
    path('admn/jobs/fullfilled',views.admin_job_view_done, name='admin_jobs_full'),
    path('admn/jobs/canceled',views.admin_job_view_canceled, name='admin_jobs_can'),

    # User API
    path('api/user/job/getupdates', views.get_job_updates, name='user_get_job'),
    path('api/user/job/create', views.job_create, name='user_create_job'),
    path('api/user/job/update/location', views.job_update_location, name='user_update_job_location'),
    path('api/user/job/rating/set', views.set_rating, name='user_job_rating_set'),

    # Test API 
    path('api/time', views.test_poll, name='time_live'),
]