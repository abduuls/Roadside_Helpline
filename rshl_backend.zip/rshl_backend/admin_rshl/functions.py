from . import models
from vendor_rshl import models as vndr_models
import smtplib
from django.conf import settings as config
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from datetime import datetime
import calendar

#--- Job Functions
def state_job_comp(status):
    state = {'Canceled':0,
             'Pending':1,
             'Rider Assigned':2,
             'Rider Assigned, Towing':3,
             'Job Fullfilled':4,
             'Job Fullfilled, Pay Pending':5,
             'Job Fullfilled, Paid':6}
    return state[status]

def job_status(j_id,rider,finished,towing,canceled,paid):
    try:
        rider_check = rider != None
    except:
        rider_check = False
    if not rider_check and not finished and not canceled:
        return 'Pending'
    elif rider_check and not finished and not canceled:
        x = ''
        if towing:
            x = ', Towing'
        return 'Rider Assigned'+x
    elif canceled:
        return 'Canceled'
    else:
        xp = ''
        if paid: # Payment Check, TODO
            xp= ', Paid'
        elif vndr_models.PaymentLog.objects.filter(service_id=j_id).exists():
            xp= ', Pay Pending'
        return 'Job Fullfilled'+xp

def get_customer(customer):
    customer_obj = customer
    return [customer.name,customer.phone]

def service_req(job_obj):
    jobs_avail =  config.VENDOR_TIER_LIST
    return  jobs_avail[f'{vndr_models.Servicelog_Servicerequired.objects.filter(service_id=job_obj).get().service}']

def job_postprocess(job):
    ret_list = []
    job_objects = job
    for sr,job_object in enumerate(job_objects,1):
        status = job_status(j_id=job_object.id,rider=job_object.rider_id,finished=job_object.finished,towing=job_object.towing,canceled=job_object.canceled,paid=job_object.paid)
        ret_list.append({
            'serial':sr,
            'job_id':job_object.id,
            'customer':get_customer(job_object.user_id),
            'service':service_req(job_object),
            'status':status,
            'vendor':job_object.vendor_id.user.last_name,
            'status_comp':state_job_comp(status)
        })
    return ret_list

#---
def get_admin(request):
    user = request.user
    user.refresh_from_db()
    trigger = user.is_superuser
    
    return trigger, user

def error_dict(error="",error_bool=False,data=""):
    return  {
            'error':error_bool,
            'error_detail':error,
            'data':data
        }

def send_email(subject: str, text: str, html: str, recipients: list):
    username = config.EMAIL_USERNAME
    password = config.EMAIL_PASSWORD
    if (not username == "" or not username == None) and (not password == "" or not password == None):
        sender = f"{username}@gmail.com"
        password = f"{password}"

        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = sender
        msg['To'] = ', '.join(recipients)

        part1 = MIMEText(text, 'plain')
        part2 = MIMEText(html, 'html')

        # Attach parts into message container.
        # According to RFC 2046, the last part of a multipart message, in this case
        # the HTML message, is best and preferred.
        msg.attach(part1)
        msg.attach(part2)

        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp_server:
            try:
                smtp_server.login(sender, password)
                smtp_server.sendmail(sender, recipients, msg.as_string())
                print("Message sent!")
            except Exception as e:
                print(f'Error: {e}')

def api_auth_client(request):
    token = str(request.headers.get('Authorization'))[7:]
    try:
        user = models.AppUser.objects.filter(token=token)
        if user.exists():
            return 200, user.get()
        else:
            return 401, None
    except Exception as e:
        print(f'{e}')
        return 401, None

def card_number_format(card_number):
    if card_number == "0":
        return "Cash"
    return f"{card_number[-4:]} {config.CARD_ID[str(card_company(card_number))]}Card"

def card_company(card_number):
    if card_number[0]=="4":
        return 1
    elif int(card_number[0]+card_number[1]) >= 51 and int(card_number[0]+card_number[1]) <= 55:
        return 2
    else:
        return 3

def card_exp_check(month,year):
    d = datetime.strptime(f"{calendar.monthrange(month=month,year=year)[1]}/{month}/{year}", "%d/%m/%Y")
    return datetime.today().date() < d.date()

def luhn_checksum(card_number):
    def digits_of(n):
        return [int(d) for d in str(n)]
    digits = digits_of(card_number)
    odd_digits = digits[-1::-2]
    even_digits = digits[-2::-2]
    checksum = 0
    checksum += sum(odd_digits)
    for d in even_digits:
        checksum += sum(digits_of(d*2))
    return checksum % 10

def is_luhn_valid(card_number):
    return luhn_checksum(card_number) == 0