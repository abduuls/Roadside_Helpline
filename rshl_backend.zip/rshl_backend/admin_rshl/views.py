from django.shortcuts import render,redirect
from . import forms,functions,models

# Vendor Imports
from vendor_rshl import models as vndr_models
from vendor_rshl import functions as vndr_func

from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required

import json

from django.contrib.auth.models import User
from django.utils.safestring import mark_safe
from django.http import JsonResponse,HttpResponseBadRequest,HttpResponse,HttpRequest,FileResponse
from django.views.decorators.csrf import csrf_exempt

from django.conf import settings as conf
from rich import print as rprint

from datetime import datetime as dt

from netifaces import interfaces, ifaddresses, AF_INET
once = True

# Create your views here.
def new_otp(userobj):
    userobj.generate_otp()
    userobj.save()
    send_otp(userobj.otp, userobj.email)

def send_otp(otp, email):
    functions.send_email("OTP Verification", f"your OTP is: {otp}", f"<h1>your OTP is: {otp}</h1>",[email])

def get_json(receive):
    return json.loads(HttpRequest.read(self=receive).decode('utf-8'))

def null_to_zero(element):
    if element == None:
        return 0.0
    return element

def give_rider_update(rider):
    if rider == None:
        return {"name":"Rider not Assigned","phone":"Rider not Assigned"}
    return {"name":rider.name,"phone":f"+92{rider.phone}"}

# Client API

# -----------User Data Templates
def send_image(request,image_name):
    img = open(f'admin_rshl/media/{image_name}', 'rb')
    return FileResponse(img)

# -----------User Action API
@csrf_exempt
def test_poll(request):
    return JsonResponse({"time":dt.now().isoformat()})

@csrf_exempt
def get_job_updates(request):
    if request.method == 'POST':
        code, user = functions.api_auth_client(request)
        if user==None:
            return JsonResponse(functions.error_dict(error='Unable to Authorize',error_bool=True),)
        else:
            if not user.verified:
                return JsonResponse(functions.error_dict(error='Not Verified',error_bool=True),)
            req = get_json(receive=request)
            
            try:
                job_id = int(req['job_id'])
            except Exception as e:
                return JsonResponse(functions.error_dict(error=f'{e}',error_bool=True))

            try:
                job_db = vndr_models.ServiceLog.objects.filter(id=job_id,user_id=user)
                if job_db.exists:
                    job_obj = job_db.get()
                    data = {
                        "UserLocation":{"latitude":null_to_zero(job_obj.location_latitude),"longitude":null_to_zero(job_obj.location_longitude)},
                        "RiderLocation":{"latitude":null_to_zero(job_obj.rider_location_latitude),"longitude":null_to_zero(job_obj.rider_location_longitude)},
                        "RiderDetail":give_rider_update(job_obj.rider_id),
                        "JobDetails":{"Finished":job_obj.finished,"Status":vndr_func.job_postprocess([job_obj])[0]['status'],"Canceled":job_obj.canceled},

                    }
                    return JsonResponse(functions.error_dict(data=data))
                else:
                    return JsonResponse(functions.error_dict(error_bool=True,error=f"Error: Job Doesn't Exists"))
                
            except Exception as e:
                return JsonResponse(functions.error_dict(error_bool=True,error=f"Error: {e}"))
    else:    
        return HttpResponseBadRequest()

@csrf_exempt
def job_create(request):
    if request.method == 'POST':
        return_dict = {
                'error':False,
                'error_detail':'',
                'data':''
            }
        code, user = functions.api_auth_client(request)
        if user==None:
            return_dict['error']=True
            return_dict['error_detail']='Unable to Authorize'
            return JsonResponse(return_dict,)
        else:
            if not user.verified:
                return_dict['error']=True
                return_dict['error_detail']='Not Verified'
                return JsonResponse(return_dict,)
            req = get_json(receive=request)
            try:
                vendor = req['Vendor']
                job_int = int(req['JobRequired'])
                pay_int = int(req['PaymentID'])
                job_dict = conf.VENDOR_TIER_LIST
                job_text = job_dict[f'{job_int}']
            except Exception as e:
                return_dict['error']=True
                return_dict['error_detail']=f'{e}'
                return JsonResponse(return_dict)
            
            try:
                lat = float(req['Latitude'])
                long = float(req['Longitude'])
            except:
                lat = None
                long = None

            vnrd_obj = models.Vendor.objects.filter(id=vendor)
            pay_obj = models.Client_Card.objects.filter(id=int(pay_int))
            pay_obj_get=None
            
            if pay_obj.exists():
                pay_obj_get = pay_obj.get()
            else:
                return_dict['error']=True
                return_dict['error_detail']='Invalid Payment Method'
                return JsonResponse(return_dict)
            
            if vnrd_obj.exists():
                job = vndr_models.ServiceLog.objects.create(
                   vendor_id=vnrd_obj.get(),
                   user_id=user,
                   user_payment=pay_obj_get,
                   location_latitude=float(lat),
                   location_longitude=float(long),
               )
                job_req = vndr_models.Servicelog_Servicerequired.objects.create(
                   service_id=job,
                   service_text=job_text,
                   service=job_int
               )
                job.save()
                job_req.save()
                return_dict['data']={'job_id':job.id,"job_updated":job.timestamp.timestamp()}
                return JsonResponse(return_dict)
            else:
                return_dict['error']=True
                return_dict['error_detail']='Vendor doesn\'t exists'
                return JsonResponse(return_dict) 

            # job = vndr_models.
    else:    
        return HttpResponseBadRequest()

@csrf_exempt
def job_update_location(request):
    # Only Created for App Purposed
    if request.method == 'POST':
        code, user = functions.api_auth_client(request)
        if user==None:
            return JsonResponse(functions.error_dict(error='Unable to Authorize',error_bool=True),)
        else:
            if not user.verified:
                return JsonResponse(functions.error_dict(error='Not Verified',error_bool=True),)
            req = get_json(receive=request)
            
            try:
                job_id = int(req['JobID'])
                lat = float(req['Latitude'])
                long = float(req['Longitude'])
            except Exception as e:
                return JsonResponse(functions.error_dict(error=f'{e}',error_bool=True))
            
            job = vndr_models.ServiceLog.objects.filter(id=job_id)
            if job.exists():
                job_obj = job.get()
                job_obj.location_latitude = lat
                job_obj.location_longitude = long
                job_obj.save()
                data = {
                    "job_updated":job_obj.timestamp.timestamp()
                }
                return JsonResponse(functions.error_dict(data=data))
            else:
                return JsonResponse(functions.error_dict(error="Error: Job Doesn't Exists",error_bool=True))
    else:    
        return HttpResponseBadRequest()

@csrf_exempt
def vendors_get(request):
    if request.method == 'POST':
        return_dict = {
                'error':False,
                'error_detail':'',
                'data':''
            }
        code, user = functions.api_auth_client(request)
        if user==None:
            return_dict['error']=True
            return_dict['error_detail']='Unable to Authorize'
            return JsonResponse(return_dict,)
        else:
            if not user.verified:
                return_dict['error']=True
                return_dict['error_detail']='Not Verified'
                return JsonResponse(return_dict,)
            req = get_json(receive=request)
            
            try:
                tier = req['Tier']
            except Exception as e:
                return_dict['error']=True
                return_dict['error_detail']=f'{e}'
                return JsonResponse(return_dict)

            vendors = models.Vendor.objects.filter(service_tier__gte=int(tier)).all().order_by("-rating")
            
            vendor_list = []
            vendor_bool = bool(len(vendors))
            for vendor in vendors:
                vendor_list.append({"vendor_name":f"{vendor.user.last_name}","vendor_phone":f"{vendor.phone}","vendor_shop":f"{vendor.shop_no}","rating":vendor.rating,"id":vendor.id})
            return_dict['data'] = {
                "vendor_bool":vendor_bool,
                "vendor_list":vendor_list
            }
            return JsonResponse(return_dict)
    else:    
        return HttpResponseBadRequest()

@csrf_exempt
def vendor_get(request):
    if request.method == 'POST':
        code, user = functions.api_auth_client(request)
        if user==None:
            return JsonResponse(functions.error_dict(error='Unable to Authorize',error_bool=True),)
        else:
            if not user.verified:
                return JsonResponse(functions.error_dict(error='Not Verified',error_bool=True),)
            req = get_json(receive=request)
            
            try:
                vendor = req['VendorID']
            except Exception as e:
                return JsonResponse(functions.error_dict(error=f'{e}',error_bool=True))
            try:
                vendor = models.Vendor.objects.filter(id=vendor).get()
                user_pay_default = models.Client_Card.objects.filter(id=user.default_payment).get()
                data = {"vendor_name":f"{vendor.user.last_name}",
                        "vendor_phone":f"{vendor.phone}",
                        "vendor_shop":f"{vendor.shop_no}",
                        "vendor_address":f"{vendor.address}",
                        "rating":vendor.rating,
                        "id":vendor.id,
                        "default_payment":{
                         "id": user_pay_default.id,
                         "card_type":user_pay_default.card_type,
                         "card_number":user_pay_default.card_number,
                         "card_disp":functions.card_number_format(user_pay_default.card_number)
                        }}
                return JsonResponse(functions.error_dict(data=data))
            except Exception as e:
                return JsonResponse(functions.error_dict(error_bool=True,error=f"Error: {e}"))        
    else:    
        return HttpResponseBadRequest()

@csrf_exempt
def verify_otp(request):

    otp = ""
    username = ""

    try:
        username = request.GET.get("username")
    except:
        return HttpResponse("<h1>User Error</h1>")

    try:
        otp = request.GET.get("otp")
    except:
        otp = None

    user = models.AppUser.objects.filter(username=username)
    if user.exists():
        userobj = user.get()
        if not otp == "" and not otp == None and not userobj.verified:
            otp_bool = userobj.check_otp(str(otp))
            if otp_bool:
                return HttpResponse("<h1>Verification Done</h1>")
            else:
                return HttpResponse("<h1>Verification Failed</h1>")
        elif userobj.verified:
            return HttpResponse("<h1>Already Verification</h1>")
        else:
            userobj.generate_otp()
            userobj.save()
            send_otp(userobj.otp, userobj.email)
            return HttpResponse("<h1>OTP Resent</h1>")
    else:
        return HttpResponse("<h1>User Doesn't Exists</h1>")

@csrf_exempt
def verify_otp_api(request):
    if request.method == 'POST':
        otp = ""
        username = ""
        req = get_json(receive=request)
        try:
            otp = req["otp"]
            action = req["action"]
            username = req["username"]
        except Exception as e:
            return JsonResponse(functions.error_dict(error_bool=True,error=f"Error: {e}"))

        user = models.AppUser.objects.filter(username=username)
        if user.exists():
            userobj = user.get()
            if action == "status":
                return JsonResponse(functions.error_dict(data={'verify_status':userobj.verified,"verify_success":False,"action_status":True}))
            elif action == "verify":
                if not otp == "" and not otp == None and not userobj.verified:
                    otp_bool = userobj.check_otp(str(otp))
                    return JsonResponse(functions.error_dict(data={'verify_status':userobj.verified,"verify_success":otp_bool,"action_status":True}))
                else:
                    return JsonResponse(functions.error_dict(data={'verify_status':userobj.verified,"verify_success":False,"action_status":False}))
            elif action == "new":
                new_otp(userobj=userobj)
                return JsonResponse(functions.error_dict(data={'verify_status':userobj.verified,"verify_success":otp_bool,"action_status":True}))
            else:
                return JsonResponse(functions.error_dict(error_bool=True,error="No Action Chosen"))
        else:   
            return JsonResponse(functions.error_dict(error="Username Doesn't Exists!",error_bool=True))
    else:
        return HttpResponseBadRequest()

@csrf_exempt
def get_old_orders(request):
    if request.method == 'POST':
        return_dict = {
                'error':False,
                'error_detail':'',
                'data':''
            }
        code, user = functions.api_auth_client(request)
        if user==None:
            return_dict['error']=True
            return_dict['error_detail']='Unable to Authorize'
            return JsonResponse(return_dict,)
        else:
            if not user.verified:
                return_dict['error']=True
                return_dict['error_detail']='Not Verified'
                return JsonResponse(return_dict,)
            # req = get_json(receive=request)
            # try:
            #     var = req['var']
            # except Exception as e:
            #     return_dict['error']=True
            #     return_dict['error_detail']=f'{e}'
            #     return JsonResponse(return_dict)
            
            jobs = vndr_models.ServiceLog.objects.filter(user_id=user).all()

            job_bool=bool(len(jobs))
            job_list = vndr_func.job_postprocess(jobs)

            return_dict['data'] = {
                'orders':job_list,
                'order_bool':job_bool
            }
            return JsonResponse(return_dict)
    else:    
        return HttpResponseBadRequest()

@csrf_exempt
def get_profile(request):
    if request.method == 'GET':
        return_dict = {
                'error':False,
                'error_detail':'',
                'data':''
            }
        code, user = functions.api_auth_client(request)
        if user==None:
            return_dict['error']=True
            return_dict['error_detail']='Unable to Authorize'
            return JsonResponse(return_dict,)
        else:
            if not user.verified:
                return_dict['error']=True
                return_dict['error_detail']='Not Verified'
                return JsonResponse(return_dict,)

            name=user.name
            email=user.email
            phone=user.phone
            username=user.username

            return_dict['data'] = {
                'name':name,
                'email':email,
                'phone':phone,
                'username':username
            }
            return JsonResponse(return_dict)
    else:    
        return HttpResponseBadRequest()

@csrf_exempt
def get_services(request):
    if request.method == 'GET':

        code, user = functions.api_auth_client(request)
        if user==None:
            return JsonResponse(functions.error_dict(error='Unable to Authorize',error_bool=True),)
        else:
            if not user.verified:
                return JsonResponse(functions.error_dict(error='Not Verified',error_bool=True),)

            raw_list = conf.VENDOR_TIER_LIST_SEND

            data = []

            for items in raw_list:
                data.append({"id":items[1],"name":items[0],"detail":items[2],"image":items[3]})

            return JsonResponse(functions.error_dict(data=data))
    else:    
        return HttpResponseBadRequest()

@csrf_exempt
def get_payment_methods(request):
    if request.method == 'GET':
        code, user = functions.api_auth_client(request)
        if user==None:
            return JsonResponse(functions.error_dict(error='Unable to Authorize',error_bool=True),)
        else:
            if not user.verified:
                return JsonResponse(functions.error_dict(error='Not Verified',error_bool=True),)

            all_cards = []
            all_cards_obj = models.Client_Card.objects.filter(card_user=user).all()
            
            if user.default_payment == None or user.default_payment == 0:
                user.default_payment= all_cards_obj[0].id
                user.save()

            for cards in all_cards_obj:
                all_cards.append({
                    "card_id":cards.id,
                    "card_name":cards.card_name,
                    "card_no":cards.card_number,
                    "card_cvv":cards.card_cvv,
                    "card_exp":{"month":cards.card_exp_month,"year":cards.card_exp_year},
                    "card_type":cards.card_type,
                    "card_type_human":conf.CARD_ID[f"{cards.card_type}"],
                    "card_disp":functions.card_number_format(cards.card_number)
                })

            data = {
                "all_methods": all_cards,
                "default_card" : user.default_payment     
            }
            return JsonResponse(functions.error_dict(data=data))
    else:    
        return HttpResponseBadRequest()

@csrf_exempt
def add_payment_methods(request):
    if request.method == 'POST':
        code, user = functions.api_auth_client(request)
        if user==None:
            return JsonResponse(functions.error_dict(error='Unable to Authorize',error_bool=True))
        else:
            if not user.verified:
                return JsonResponse(functions.error_dict(error='Not Verified',error_bool=True))
            req = get_json(receive=request)
            
            try:
                card_number = req['Number']
                card_cvv = req['Cvv']
                card_exp_month = int(req['ExpMonth'])
                card_exp_year = int(req['ExpYear'])
                card_name = req['Name']
            except Exception as e:
                return JsonResponse(functions.error_dict(error=f'{e}',error_bool=True))
            data = {}
            if functions.card_company(card_number) != 3 and functions.is_luhn_valid(card_number):
                if functions.card_exp_check(month=card_exp_month,year=card_exp_year):
                    card_obj = models.Client_Card.objects.create(
                    card_user = user,
                    card_number = card_number,
                    card_cvv = card_cvv,
                    card_exp_month = card_exp_month,
                    card_exp_year = card_exp_year,
                    card_type = functions.card_company(card_number),
                    card_name = card_name
                    )
                    card_obj.save()
                    data = {
                        "card_valid":functions.is_luhn_valid(card_number),
                        "card_expired":not functions.card_exp_check(month=card_exp_month,year=card_exp_year),
                        "card_added":True
                    }
                    return JsonResponse(functions.error_dict(data=data))
                else:
                    data = {
                        "card_valid":functions.is_luhn_valid(card_number),
                        "card_expired":not functions.card_exp_check(month=card_exp_month,year=card_exp_year),
                        "card_added":False
                    }
                    return JsonResponse(functions.error_dict(error="Error: Card is Expired",error_bool=True,data=data))
            else:
                data = {
                        "card_valid":functions.is_luhn_valid(card_number),
                        "card_expired":not functions.card_exp_check(month=card_exp_month,year=card_exp_year),
                        "card_added":False
                    }
                return JsonResponse(functions.error_dict(error="Error: Card is Invalid or Not Supported",error_bool=True,data=data))
    else:    
        return HttpResponseBadRequest()

@csrf_exempt
def set_default_payment(request):
    if request.method == 'POST':
        code, user = functions.api_auth_client(request)
        if user==None:
            return JsonResponse(functions.error_dict(error='Unable to Authorize',error_bool=True),)
        else:
            if not user.verified:
                return JsonResponse(functions.error_dict(error='Not Verified',error_bool=True),)
            req = get_json(receive=request)
            
            try:
                default_id = req['DefaultPaymentID']
            except Exception as e:
                return JsonResponse(functions.error_dict(error=f'{e}',error_bool=True))
            
            card_check = models.Client_Card.objects.filter(card_user=user,id=int(default_id))

            if card_check.exists():
                user.default_payment = default_id
                data = {
                    "DefaultSet":True
                }
                return JsonResponse(functions.error_dict(data=data))
            else:
                return JsonResponse(functions.error_dict(error="Error: Counldn't Set Default",error_bool=True))
    else:    
        return HttpResponseBadRequest()

@csrf_exempt
def set_rating(request):
    if request.method == 'POST':
        code, user = functions.api_auth_client(request)
        if user==None:
            return JsonResponse(functions.error_dict(error='Unable to Authorize',error_bool=True),)
        else:
            if not user.verified:
                return JsonResponse(functions.error_dict(error='Not Verified',error_bool=True),)
            req = get_json(receive=request)
            
            try:
                jid = req['JobID']
                rsv_rating = float(req['Rating'])
            except Exception as e:
                return JsonResponse(functions.error_dict(error=f'{e}',error_bool=True))
            
            job_db = vndr_models.ServiceLog.objects.filter(id=jid)
            if job_db.exists:
                jobj = job_db.get()
                jobj.rating = rsv_rating
                try:
                    t_rsv_rating = req['TextRating']
                    jobj.rating_text = t_rsv_rating
                except:
                    pass
                jobj.save()
                all_jobs = vndr_models.ServiceLog.objects.filter(vendor_id=jobj.vendor_id,rating__isnull=False).all()
                rating_count = all_jobs.count()
                ratings = 0.0
                for r in all_jobs:
                    ratings=ratings+r.rating
                rating_avg=0.0
                
                try:
                    rating_avg = ratings/rating_count
                except:
                    rating_avg = 0.0

                jobj.vendor_id.rating = rating_avg
                jobj.vendor_id.save()
                
                return JsonResponse(functions.error_dict(data={"CVR":jobj.vendor_id.rating}))
            else:
                return JsonResponse(functions.error_dict(error_bool=True,error="Error: Job Doesn't Exists"))

    else:    
        return HttpResponseBadRequest()

# API Template:
def template(request):
    if request.method == 'POST':
        code, user = functions.api_auth_client(request)
        if user==None:
            return JsonResponse(functions.error_dict(error='Unable to Authorize',error_bool=True),)
        else:
            if not user.verified:
                return JsonResponse(functions.error_dict(error='Not Verified',error_bool=True),)
            req = get_json(receive=request)
            
            try:
                var = req['var']
            except Exception as e:
                return JsonResponse(functions.error_dict(error=f'{e}',error_bool=True))
            
            data = {

            }
            return JsonResponse(functions.error_dict(data=data))
    else:    
        return HttpResponseBadRequest()
    
# -----------User Login API
@csrf_exempt
def client_login(request):
    if request.method == 'POST':
        return_dict = {
            'error':False,
            'error_detail':'',
            'token':'',
            'verified':False,
            'email':''
        }
        auth = get_json(receive=request)
        try:
            username = auth['username']
            password = auth['password']
        except Exception as e:
            return_dict['error']=True
            return_dict['error_detail']=f'{e}'
            return JsonResponse(return_dict)
        
        user = models.AppUser.objects.filter(username=username)

        if user.exists():
            w_user = user.get()
            if w_user.check_pass(password):
                return_dict['token'] = f'{w_user.token}'
                return_dict['verified'] = w_user.verified
                if not w_user.verified:
                    new_otp(w_user)
                return_dict['email'] = w_user.email
                return JsonResponse(return_dict)
            else:
                return_dict['error']=True
                return_dict['error_detail']=f'Error: Wrong Password!'
                return JsonResponse(return_dict)    
        else:
            return_dict['error']=True
            return_dict['error_detail']=f'Error: Signup First, User doesn\'t Exists.'
            return JsonResponse(return_dict)
    else:    
        return HttpResponseBadRequest()
    
@csrf_exempt
def client_signup(request):
    if request.method == 'POST':
        return_dict = {
            'error':False,
            'error_detail':'',
            'token':'',
            'verified':False,
            'email':''
        }
        auth = get_json(receive=request)
        try:
            name = auth['name']
            username = auth['username']
            password = auth['password']
            email = auth['email']
            phone = int(auth['phone'])
        except Exception as e:
            return_dict['error']=True
            return_dict['error_detail']=f'{e}'
            return JsonResponse(return_dict)
        
        user = models.AppUser.objects.filter(username=username)

        if not user.exists():
            user_sign = models.AppUser.objects.create(name=name,
                                                      username=username,
                                                      email=email,
                                                      phone=phone)
            user_sign.create_pass(password)
            user_sign.save()
            default_payment = models.Client_Card.objects.create(
                card_user = user_sign,
                card_number = "0",
                card_cvv = "0",
                card_exp_month = 0,
                card_exp_year = 0,
                card_type = 0 ,
                card_name = "CASH",
                allow_delete = False,
            )
            default_payment.save()
            user_sign.default_payment = default_payment.id
            user_sign.save()
            token = user_sign.token
            return_dict['token'] = token
            return_dict['verified'] = user_sign.verified
            return_dict['email'] = user_sign.email
            new_otp(userobj=user_sign)
            return JsonResponse(return_dict)
        else:
            return_dict['error']=True
            return_dict['error_detail']=f'Error: User already Exists.'
            return JsonResponse(return_dict)
    else:    
        return HttpResponseBadRequest()

# -----------Admin Templates Render
def all_logout(request):
    if request.user.is_authenticated:
        logout(request=request)
    return redirect('root')

def all_login(request):
    context = {'error':''}
    if request.user.is_authenticated:
        return redirect('root')
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request=request,username=username,password=password,)
        if user is not None:
            login(request=request,user=user)
            return redirect('root')
        else:
            context['error']='Error: Incorrect Username or Password'
    return render(request, 'auth/login.html', context)

@login_required
def root_render(request):
    return render(request, 'home.html')

@login_required
def vendor_reg(request):
    trigger, user = functions.get_admin(request)
    if not trigger:
        return redirect('root')

    title = 'Vendor Registration'
    if request.method == 'POST':
        
        username = request.POST['username']
        name = request.POST['name']
        email = request.POST['email']
        password = request.POST['password']
        address = request.POST['address']
        phone = request.POST['phone']
        shop_no = request.POST['shop_no']
        tier = request.POST['tier']

        if not User.objects.filter(username=username).exists():
            # new_vendor = User.objects.create(
            #             username=username,
            #             email=email,
            #             last_name=name,
            #             is_staff=False
            #                                 )
            new_vendor = User.objects.create_user(username=username,email=email,password=password,last_name=name)
            new_vendor_raw = models.Vendor.objects.create(user=new_vendor,address=address,phone=phone,shop_no=shop_no,service_tier=tier).save()
            return redirect('root')     
    form = forms.VendorReg()
    context = {'form':form,'title':title}
    return render(request, 'auth/vendor_form.html',context)

@login_required()
def vendor_view(request):
    title = 'Vendor View'
    trigger, user = functions.get_admin(request)
    
    if not trigger:
        return redirect('root')

    vendors = models.Vendor.objects.all()
    
    vendor_list = []
    for vendor in vendors:
        vendor_list.append({
            'id':vendor.id,
            'name':vendor.user.last_name,
            'username':vendor.user.username,
            'phone':vendor.phone,
            'rating':vendor.rating
        })
    context = {'title':title,'vendors':vendor_list}
    return render(request, 'vendor_pages/vendor_view.html', context)

## Job Views Admin
@login_required()  
def admin_job_view_all(request):
    trigger, user = functions.get_admin(request)
    if not trigger:
        return redirect('root')
    jobs = vndr_models.ServiceLog.objects.all()
    context = {'job':functions.job_postprocess(jobs), 'title':'Jobs - All'}
    return render(request, 'jobs/admin_jobs_view.html',context)
    
@login_required()  
def admin_job_view_done(request):
    trigger, user = functions.get_admin(request)
    if not trigger:
        return redirect('root')
    jobs = vndr_models.ServiceLog.objects.all()
    jobs_processed = functions.job_postprocess(jobs)
    extra_processing = []
    for job in jobs_processed:
        if job['status'] == 'Job Fullfilled' or job['status'] == 'Job Fullfilled, Paid' and not job['status'] == 'Canceled':
            extra_processing.append(job)
    context = {'job':extra_processing, 'title':'Jobs - Fullfilled'}
    return render(request, 'jobs/admin_jobs_view.html',context)

@login_required()  
def admin_job_view_pending(request):
    trigger, user = functions.get_admin(request)
    if not trigger:
        return redirect('root')
    jobs = vndr_models.ServiceLog.objects.all()
    jobs_processed = functions.job_postprocess(jobs)
    extra_processing = []
    for job in jobs_processed:
        print(job['status'])
        if job['status']=='Pending' or job['status']=='Rider Assigned' or job['status']=='Rider Assigned, Towing':
            extra_processing.append(job)
    context = {'job':extra_processing, 'title':'Jobs - Ongoing'}
    return render(request, 'jobs/admin_jobs_view.html',context)

@login_required()  
def admin_job_view_canceled(request):
    trigger, user = functions.get_admin(request)
    if not trigger:
        return redirect('root')
    jobs = vndr_models.ServiceLog.objects.all()
    jobs_processed = functions.job_postprocess(jobs)
    extra_processing = []
    for job in jobs_processed:
        if job['status'] == 'Canceled':
            extra_processing.append(job)
    context = {'job':extra_processing, 'title':'Jobs - Canceled'}
    return render(request, 'jobs/admin_jobs_view.html',context)

if once:
    ip_list = []
    x = 1
    for ifaceName in interfaces():
        ip = ifaddresses(ifaceName).setdefault(AF_INET,[{"addr":"0"}])[0]['addr']
        if not ip == "0" and not ip == "127.0.0.1":
            ip_list.append(f"IP#{x}: {ip}\n")
            x=x+1
    rprint("".join(ip_list))
    once=False