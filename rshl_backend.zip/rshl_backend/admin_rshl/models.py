from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
import uuid
import hashlib
import random

# Create your models here.

class Vendor(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    address = models.CharField(max_length=128)
    phone = models.IntegerField()
    shop_no = models.CharField(max_length=128)
    first_sign = models.BooleanField(default=True)
    service_tier = models.SmallIntegerField()
    rating = models.FloatField(default=0.0)

    def __str__(self) -> str:
        return f'{self.user.last_login}|{self.shop_no}'

#CLIENT THING
class AppUser(models.Model):
    name = models.CharField(max_length=255,default='NEW USER')
    email = models.CharField(max_length=150, default='null@localhost.local')
    phone = models.CharField(max_length=11)
    username = models.CharField(max_length=128,unique=True)
    token = models.UUIDField(unique=True,default=uuid.uuid4,editable=False)
    password = models.CharField(max_length=512)
    verified = models.BooleanField(default=False)
    otp =  models.CharField(max_length=6,null=True)
    deleted = models.BooleanField(default=False)
    default_payment = models.IntegerField(null=True)
    created = models.CharField(max_length=255, default=f'{timezone.datetime.today().isoformat()}')
    update = models.CharField(max_length=255, default=f'{timezone.datetime.today().isoformat()}')

    def generate_otp(self):
        x=0
        otp = ""
        while(x<6):
            random_number = random.randrange(0,9)
            otp = otp+str(random_number)
            x=x+1
        self.otp = otp

    def check_otp(self, raw_otp):
        verify = (raw_otp == self.otp)
        if verify:
            self.verified = True
            self.otp = None
            self.save()
        return verify

    def check_pass(self, raw_pass):
        hash = hashlib.sha256()
        hash.update(bytes(f'{raw_pass}','utf-8'))
        if hash.hexdigest() == self.password:
            return True
        else:
            return False

    def create_pass(self, raw_pass):
        hash = hashlib.sha256()
        hash.update(bytes(f'{raw_pass}','utf-8'))
        self.password = hash.hexdigest()

    def update_timestamp(self):
        self.created=f'{timezone.datetime.today().isoformat()}'

    def __str__(self) -> str:
        return f'{self.name}|{self.created}'
    
class Client_Card(models.Model):
    card_user = models.ForeignKey(AppUser, on_delete=models.CASCADE)
    card_number = models.CharField(max_length=17)
    card_cvv = models.CharField(max_length=5)
    card_exp_month = models.IntegerField()
    card_exp_year = models.IntegerField()
    card_type = models.SmallIntegerField()
    card_name = models.CharField(max_length=100)
    allow_delete = models.BooleanField(default=False)

    def __str__(self) -> str:
        return f'{self.card_name}|{self.card_number}'