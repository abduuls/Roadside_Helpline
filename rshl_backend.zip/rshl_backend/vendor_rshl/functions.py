from django.conf import settings as config
from . import models
from admin_rshl import models as admin_model

# Vendor Function
def get_vendor(request):
    user = request.user
    user.refresh_from_db()
    vendor = ''
    trigger = False
    try:
        vendor = admin_model.Vendor.objects.filter(user=user).get()
    except:
        trigger = True
    
    return vendor,trigger, user

# Job Functions
def state_job_comp(status):
    state = {'Canceled':0,
             'Pending':1,
             'Rider Assigned':2,
             'Rider Assigned, Towing':3,
             'Job Fullfilled':4,
             'Job Fullfilled, Pay Pending':5,
             'Job Fullfilled, Paid':6}
    return state[status]

def job_status(j_id,rider,finished,towing,canceled,paid):
    try:
        rider_check = rider != None
    except:
        rider_check = False
    if not rider_check and not finished and not canceled:
        return 'Pending'
    elif rider_check and not finished and not canceled:
        x = ''
        if towing:
            x = ', Towing'
        return 'Rider Assigned'+x
    elif canceled:
        return 'Canceled'
    else:
        xp = ''
        if paid: # Payment Check, TODO
            xp= ', Paid'
        elif models.PaymentLog.objects.filter(service_id=j_id).exists():
            xp= ', Pay Pending'
        return 'Job Fullfilled'+xp

def get_customer(customer):
    customer_obj = customer
    return [customer.name,customer.phone]

def service_req(job_obj):
    jobs_avail =  config.VENDOR_TIER_LIST
    return  jobs_avail[f'{models.Servicelog_Servicerequired.objects.filter(service_id=job_obj).get().service}']

def job_postprocess(job):
    ret_list = []
    job_objects = job
    for sr,job_object in enumerate(job_objects,1):
        status = job_status(j_id=job_object.id,rider=job_object.rider_id,finished=job_object.finished,towing=job_object.towing,canceled=job_object.canceled,paid=job_object.paid)
        ret_list.append({
            'serial':sr,
            'job_id':job_object.id,
            'customer':get_customer(job_object.user_id),
            'service':service_req(job_object),
            'status':status,
            'status_comp':state_job_comp(status)
        })
    return ret_list

# Rider Functions
def rider_job(rider):
    job_id = rider.job_assigned
    if job_id == None or job_id == 0:
        return 'No Job Assigned'
    else:
        # job = models.ServiceLog.objects.get(id=job_id)
        return f'Job#{job_id} Assigned'

def api_auth_rider(request):
    token = str(request.headers.get('Authorization'))[7:]
    try:
        user = models.HAsset.objects.filter(token=token)
        if user.exists():
            return 200, user.get()
        else:
            return 401, None
    except Exception as e:
        print(f'{e}')
        return 401, None

def error_dict(error="",error_bool=False,data=""):
    return  {
            'error':error_bool,
            'error_detail':error,
            'data':data
        }

# Service Rep
def pay_details(pay_info):
    ret_list = []
    for details in enumerate(pay_info,1):
        ret_list.append(
            {'detail':details.work_done,
             'ammount':details.work_cost
             }
        )
    return ret_list

def report_list(jobs_obj):
    jobs_formated = []

    for job in jobs_obj:
        job_user = job.user_id
        job_req = models.Servicelog_Servicerequired.objects.filter(service_id=job).get()
        pay = models.PaymentLog.objects.filter(service_id=job)
        pay_info = []
        pay_info_bool = False
        total_cost = "n/a"
        if pay.exists():
            pay_info_bool = True
            pay_obj = pay.get()
            total_cost = f"{pay_obj.total_cost} Rs"
            pay_info_obj = models.ServiceDoneDetail.objects.filter(service_id=job).all()
            pay_info = pay_details(pay_info_obj)
        jobs_formated.append(
            {"c_name":job_user.name,
             "c_phone":job_user.phone,
             "job_req":job_req.service_text,
             "cost":total_cost,
             "status":job.paid,
             "details":pay_info,
             "details_bool":pay_info_bool
            }
        )

    return jobs_formated
