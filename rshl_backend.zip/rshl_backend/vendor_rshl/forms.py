from django import forms
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout,Submit
from django.utils.safestring import mark_safe
class RiderReg(forms.Form):
    username = forms.CharField(label='Username', max_length=100) 
    name = forms.CharField(label='Full Name', max_length=100)
    phone = forms.CharField(label='Phone#',max_length=11,widget=forms.NumberInput())
    email = forms.EmailField(label='Email', max_length=100)
    password = forms.CharField(label='Password',widget=forms.PasswordInput(),max_length=40)
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper(self)
        self.helper.add_input(Submit(name='submit',value='Submit'))
        self.helper.form_method='POST'
    
class RiderAssign(forms.Form):
    riders = forms.ChoiceField(label='Select Rider', widget=forms.RadioSelect())
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper(self)
        self.helper.add_input(Submit(name='submit',value='Assign'))
        self.helper.form_method='POST'