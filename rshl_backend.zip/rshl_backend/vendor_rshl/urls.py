from django.urls import path,include
from . import views



urlpatterns = [
    # Rider API
    path('api/rider/login',views.rider_login, name='rider_login'),
    path('api/rider/job/pushupdates',views.update_location, name='rider_updates'),
    path('api/rider/job/actions',views.rider_actions, name='rider_actions'),
    path('api/rider/job/get',views.get_rider_jobs, name='rider_jobs'),

    # Job URLs
    path('vendor/jobs/all',views.job_view_all, name='jobs_all'),
    path('vendor/jobs/pending',views.job_view_pending, name='jobs_pend'),
    path('vendor/jobs/fullfilled',views.job_view_done, name='jobs_full'),
    path('vendor/jobs/canceled',views.job_view_canceled, name='jobs_can'),
    # Job SubURLS
    path('vendor/job/action/<job>/<action>',views.job_action, name='jobs_action'),
    path('vendor/job/assign/<job>',views.assign_rider, name='jobs_assign'),
    path('vendor/job/bill/<job>',views.gen_bill, name='jobs_bill_gen'),

    # Rider URLs
    path('vendor/rider/signup',views.rider_reg, name='rider_reg'),
    path('vendor/rider/view',views.rider_view, name='rider_view'),

    # Reports
    path('vendor/report/sales', views.sale_view, name='sale_report'),
]