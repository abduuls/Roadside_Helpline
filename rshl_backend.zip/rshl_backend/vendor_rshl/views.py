from django.shortcuts import render,redirect
from django.template.loader import render_to_string
from . import forms,functions,models
from django.contrib.auth.models import User
from admin_rshl import models as admin_model

from django.contrib.auth.decorators import login_required

from rich import print as rp

from admin_rshl import functions as admin_func

from . import functions
from . import forms

import json

from django.http import JsonResponse,HttpResponseBadRequest ,HttpRequest
from django.views.decorators.csrf import csrf_exempt

# Create your views here.
def null_to_zero(element):
    if element == None:
        return 0.0
    return element

def get_json(receive):
    return json.loads(HttpRequest.read(self=receive).decode('utf-8'))

# Client API

# -----------Rider API
@csrf_exempt
def rider_login(request):
    if request.method == 'POST':
        return_dict = {
            'error':False,
            'error_detail':'',
            'token':''
        }
        auth = get_json(receive=request)
        try:
            username = auth['username']
            password = auth['password']
        except Exception as e:
            return_dict['error']=True
            return_dict['error_detail']=f'{e}'
            return JsonResponse(return_dict)
        
        user = models.HAsset.objects.filter(username=username)

        if user.exists():
            w_user = user.get()
            if w_user.check_pass(password):
                return_dict['token'] = f'{w_user.token}'
                return JsonResponse(return_dict)
            else:
                return_dict['error']=True
                return_dict['error_detail']=f'Error: Wrong Password!'
                return JsonResponse(return_dict)    
        else:
            return_dict['error']=True
            return_dict['error_detail']=f'Error: Signup First, User doesn\'t Exists.'
            return JsonResponse(return_dict)
    else:    
        return HttpResponseBadRequest()

@csrf_exempt
def update_location(request):
    if request.method == 'POST':
        code, user = functions.api_auth_rider(request)
        if user==None:
            return JsonResponse(functions.error_dict(error='Unable to Authorize',error_bool=True),)
        else:
            req = get_json(receive=request)
            
            try:
                job_id = int(req['JobID'])
            except Exception as e:
                return JsonResponse(functions.error_dict(error=f'{e}',error_bool=True))
            
            try:
                lat = float(req['Latitude'])
                long = float(req['Longitude'])
            except:
                lat = 0.0
                long = 0.0

            job = models.ServiceLog.objects.filter(id=job_id)
            if job.exists():
                job_obj = job.get()
                job_obj.rider_location_latitude = lat
                job_obj.rider_location_longitude = long
                job_obj.save()
                data = {
                    "UserLocation":{"latitude":null_to_zero(job_obj.location_latitude),"longitude":null_to_zero(job_obj.location_longitude)},
                    "RiderLocation":{"latitude":null_to_zero(job_obj.rider_location_latitude),"longitude":null_to_zero(job_obj.rider_location_longitude)},
                    "UserDetail":{"name":job_obj.user_id.name,"phone":f"+92{job_obj.user_id.phone}"},
                    "JobDetails":{"Finished":job_obj.finished,"Status":functions.job_postprocess([job_obj])[0]['status'],"Canceled":job_obj.canceled,"job_updated":job_obj.timestamp.timestamp(),"Towing":job_obj.towing},
                }
                return JsonResponse(functions.error_dict(data=data))
            else:
                return JsonResponse(functions.error_dict(error="Error: Job Doesn't Exists",error_bool=True))
    else:    
        return HttpResponseBadRequest()

@csrf_exempt
def rider_actions(request):
    if request.method == 'POST':
        code, user = functions.api_auth_rider(request)
        if user==None:
            return JsonResponse(functions.error_dict(error='Unable to Authorize',error_bool=True),)
        else:
            req = get_json(receive=request)
            
            try:
                job_id = int(req['JobID'])
                action = int(req['ActionID'])
            except Exception as e:
                return JsonResponse(functions.error_dict(error=f'{e}',error_bool=True))
            
            job_db = models.ServiceLog.objects.filter(id=job_id,rider_id=user)
            if job_db.exists:
                return_dic = {}
                job = job_db.get()
                if action == 1:
                    job.towing = True
                    job.save()
                    return_dic = functions.error_dict(data={"success":True,"detail":"Tow Engaged"})
                if action == 2:
                    job.finished =True
                    job.save()
                    user.job_assigned = None
                    user.save()
                    return_dic = functions.error_dict(data={"success":True,"detail":"Finished"})
                else:
                    return_dic = functions.error_dict(error_bool=True,error="No Related Action",data={"success":False,"detail":"No Related Action"})
                return JsonResponse(return_dic)
            else:
                return JsonResponse(functions.error_dict(error_bool=True,error="Error: Job Doesn't Exists"))
    else:    
        return HttpResponseBadRequest()

@csrf_exempt
def get_rider_jobs(request):
    def job_dict(job : models.ServiceLog):
        return {"id":job.id,
                "client":job.user_id.name,
                "phone":job.user_id.phone,
                "status":functions.job_postprocess([job])[0]['status'],
                "status_comp":functions.job_postprocess([job])[0]['status_comp'],
                "job_req":functions.job_postprocess([job])[0]['service']}

    if request.method == 'GET':
        code, user = functions.api_auth_rider(request)
        if user==None:
            return JsonResponse(functions.error_dict(error='Unable to Authorize',error_bool=True),)
        else:
            rider_jobs = models.ServiceLog.objects.filter(rider_id=user).all()
            rider_assigned_job = models.ServiceLog.objects.filter(id=user.job_assigned)
            rider_assigned_job_result = {}
            if rider_assigned_job.exists():
                rider_assigned_job_obj = rider_assigned_job.get()
                rider_jobs = rider_jobs.exclude(id = user.job_assigned)
                rider_assigned_job_result = job_dict(rider_assigned_job_obj)
            jobs_send = [job_dict(jobs) for jobs in rider_jobs]
            jobs_send.reverse()
            data = {
                "assigned_bool":rider_assigned_job.exists(),
                "assigned":rider_assigned_job_result,
                "all_jobs":jobs_send
            }
            return JsonResponse(functions.error_dict(data=data))
    else:    
        return HttpResponseBadRequest()

# API Template:
def template(request):
    if request.method == 'POST':
        code, user = functions.api_auth_rider(request)
        if user==None:
            return JsonResponse(functions.error_dict(error='Unable to Authorize',error_bool=True),)
        else:
            req = get_json(receive=request)
            
            try:
                var = req['var']
            except Exception as e:
                return JsonResponse(functions.error_dict(error=f'{e}',error_bool=True))
            
            data = {

            }
            return JsonResponse(functions.error_dict(data=data))
    else:    
        return HttpResponseBadRequest()

### --- Vendor's Job
@login_required()  
def job_view_all(request):
    vendor, trigger, user = functions.get_vendor(request)
    if trigger:
        return redirect('root')
    jobs = models.ServiceLog.objects.filter(vendor_id=vendor).all()
    context = {'job':functions.job_postprocess(jobs), 'title':'Jobs - All'}
    return render(request, 'jobs/jobs_view.html',context)
    
@login_required()  
def job_view_done(request):
    user = request.user
    user.refresh_from_db()
    try:
        vendor = admin_model.Vendor.objects.filter(user=user).get()
    except:
        return redirect('root')
    jobs = models.ServiceLog.objects.filter(vendor_id=vendor).all()
    jobs_processed = functions.job_postprocess(jobs)
    extra_processing = []
    for job in jobs_processed:
        if job['status'] == 'Job Fullfilled' or job['status'] == 'Job Fullfilled, Paid' and not job['status'] == 'Canceled':
            extra_processing.append(job)
    context = {'job':extra_processing, 'title':'Jobs - Fullfilled'}
    return render(request, 'jobs/jobs_view.html',context)

@login_required()  
def job_view_pending(request):
    user = request.user
    user.refresh_from_db()
    try:
        vendor = admin_model.Vendor.objects.filter(user=user).get()
    except:
        return redirect('root')
    jobs = models.ServiceLog.objects.filter(vendor_id=vendor).all()
    jobs_processed = functions.job_postprocess(jobs)
    extra_processing = []
    for job in jobs_processed:
        print(job['status'])
        if job['status']=='Pending' or job['status']=='Rider Assigned' or job['status']=='Rider Assigned, Towing':
            extra_processing.append(job)
    context = {'job':extra_processing, 'title':'Jobs - Ongoing'}
    return render(request, 'jobs/jobs_view.html',context)

@login_required()  
def job_view_canceled(request):
    user = request.user
    user.refresh_from_db()
    try:
        vendor = admin_model.Vendor.objects.filter(user=user).get()
    except:
        return redirect('root')
    jobs = models.ServiceLog.objects.filter(vendor_id=vendor).all()
    jobs_processed = functions.job_postprocess(jobs)
    extra_processing = []
    for job in jobs_processed:
        if job['status'] == 'Canceled':
            extra_processing.append(job)
    context = {'job':extra_processing, 'title':'Jobs - Canceled'}
    return render(request, 'jobs/jobs_view.html',context)

@login_required()  
def job_action(request, job, action):
    try:
        redir = request.GET.get("redirect").replace("'","")
    except:
        redir = 'root'

    job = models.ServiceLog.objects.get(id=(int(job)))
    act = int(action)
    
    if act == 0:
        job.canceled = True
        job.finished = True
        job.save()

    if act == 1:
        return redirect('jobs_assign', job=job.id)
    
    if act == 2:
        job.towing = True
        job.save()

    if act == 3:
        job.finished =True
        job.save()
        if job.rider_id != None:
            rider = job.rider_id
            rider.job_assigned = None
            rider.save()
        else:
            return redirect('root')
        
    if act == 4:
        return redirect('jobs_bill_gen', job=job.id)
    
    if act == 5:
        job.paid = True
        job.save()
        pay = models.PaymentLog.objects.filter(service_id=job).get()
        pay.payment_done=True
        pay.save()

    if  act == 6: #Send Receipt
        job_detail_db = models.ServiceDoneDetail.objects.filter(service_id=job).all()
        send_list = [{"description":x.work_done,"amount":x.work_cost} for x in job_detail_db]
        send_bool = bool(len(send_list))
        card_bool = bool(int(job.user_payment.card_number))
        context = {
            "name":job.user_id.name,
            "total":models.PaymentLog.objects.filter(service_id=job).get().total_cost,
            "items": send_list,
            "item_bool":send_bool,
            "order_id":f"Order#{job.id}",
            "date":job.created.split("T")[0],
            "card_disp":admin_func.card_number_format(job.user_payment.card_number),
            "card_bool":card_bool
        }
        email_temp = render_to_string('transaction/receipt.html',context)
        admin_func.send_email("Receipt","View HTML Attacment",email_temp,[job.user_id.email])
    
    if  act == 7: #Send Invoice
        job_detail_db = models.ServiceDoneDetail.objects.filter(service_id=job).all()
        send_list = [{"description":x.work_done,"amount":x.work_cost} for x in job_detail_db]
        send_bool = bool(len(send_list))
        context = {
            "name":job.user_id.name,
            "vendor":job.vendor_id.user.last_name,
            "rider":job.rider_id.name,
            "order_id":f"Order#{job.id}",
            "date":job.created.split("T")[0],
            "items": send_list,
            "item_bool":send_bool,
            "total":models.PaymentLog.objects.filter(service_id=job).get().total_cost
        }
        email_temp = render_to_string('transaction/invoice.html',context)
        admin_func.send_email("Invoice","View HTML Attacment",email_temp,[job.user_id.email,job.rider_id.email])

    # print(f'{job} {action} {request.GET.get("redirect")}')
    return redirect(redir)

# Job Action Sub URL
@login_required()
def assign_rider(request,job):

    title = 'Rider Assign'
    vendor, trigger, user = functions.get_vendor(request)
    
    if trigger:
        return redirect('root')

    try:
        redir = request.GET.get("redirect").replace("'","")
    except:
        redir = 'root'
    
    if request.method == 'POST':
        rider_id = request.POST['riders']
        rider_obj = models.HAsset.objects.filter(id=int(rider_id))
        job_obj = models.ServiceLog.objects.filter(id=int(job))
        if rider_obj.exists() and job_obj.exists():
            job_obj = job_obj.get()
            rider_obj = rider_obj.get()
            job_obj.rider_id = rider_obj
            rider_obj.job_assigned = job_obj.id
            job_obj.save()
            rider_obj.save()
            return redirect(redir)
        else:
            return redirect('root')

    
    rider_list_raw = models.HAsset.objects.filter(vendor_id=vendor, deleted=False).values_list('id','name','job_assigned')
    rider_choice = []
    for rider in rider_list_raw:
        if rider[2] == 0 or rider[2] == None:
            rider_choice.append((f'{rider[0]}',f'{rider[1]}'))

    form = forms.RiderAssign()

    form.fields['riders'].choices = rider_choice
    print(form.fields['riders']._choices)

    context = {'form':form,'title':title}
    return render(request, 'rider/rider_assign.html',context)

@login_required()
def gen_bill(request,job):

    title = 'Bill Generator'
    vendor, trigger, user = functions.get_vendor(request)

    job_obj =  models.ServiceLog.objects.get(id=int(job))

    if trigger:
        return redirect('root')

    try:
        redir = request.GET.get("redirect").replace("'","")
    except:
        redir = 'root'

    if request.method == 'POST':
        data = request.POST.dict()
        data.pop('csrfmiddlewaretoken')
        data_keys = data.keys()
        data_cleaned = {}
        s_t = 0
        for d in data_keys:
            if '_n' in d:
                val = d.rstrip("_n")+"_p"
                data_cleaned[f'{data[d]}'] = data[val]
                models.ServiceDoneDetail.objects.create(
                    service_id=job_obj,
                    work_done=f'{data[d]}',
                    work_cost=int(data[val])
                ).save()
                s_t = s_t + int(data[val])

        pay_obj = job_obj.user_payment
        pay_type = 1
        pay_done = True

        if pay_obj.card_type == 0:
            pay_type = 0
            pay_done = False
        else:
            job_obj.paid = pay_done
            job_obj.save()

        models.PaymentLog.objects.create(
                    service_id=job_obj,
                    total_cost=s_t,
                    payment_method=pay_type,
                    payment_detail=pay_obj,
                    payment_done = pay_done
                ).save()
        return redirect('jobs_all')

    context = {'title':title,
            'c_n':job_obj.user_id.name,
            'c_ph': job_obj.user_id.phone,
            'job': models.Servicelog_Servicerequired.objects.get(service_id=job).service_text}
    
    return render(request, 'jobs/bill_generator.html', context)

### --- Rider Views
@login_required()
def rider_reg(request):
    title = 'Rider Registration'
    vendor, trigger, user = functions.get_vendor(request)
    
    if trigger:
        return redirect('root')
    
    if request.method == 'POST':
        
        username = request.POST['username']
        name = request.POST['name']
        email = request.POST['email']
        password = request.POST['password']
        phone = request.POST['phone']

        if not models.HAsset.objects.filter(username=username).exists():
            new_rider = models.HAsset.objects.create(
                vendor_id=vendor,
                name = name,
                username = f'{username}.{user.username}',
                email= email,
                phone = phone,
            )
            new_rider.create_pass(password)
            new_rider.save()
            return redirect('root')     
    form = forms.RiderReg()
    context = {'form':form,'title':title}
    return render(request, 'rider/rider_signup.html',context)

@login_required()
def rider_view(request):
    title = 'Rider View'
    vendor, trigger, user = functions.get_vendor(request)
    
    if trigger:
        return redirect('root')

    try:
        del_id = request.GET.get("delete").replace("'","")
        d_rider = models.HAsset.objects.filter(vendor_id=vendor, id=del_id)
        if d_rider.exists():
            d_rider = d_rider.get()
            if not d_rider.deleted:
                d_rider.deleted = True
                d_rider.save()
    except:
        pass

    riders = models.HAsset.objects.filter(vendor_id=vendor, deleted=False).all()
    
    rider_list = []
    for rider in riders:
        rider_list.append({
            'id':rider.id,
            'name':rider.name,
            'username':rider.username,
            'email':rider.email,
            'job':functions.rider_job(rider)
        })
    context = {'title':title,'rider':rider_list}
    return render(request, 'rider/rider_view.html', context)

### --- Reports?
def sale_view(request):
    title = 'Bill Generator'
    vendor, trigger, user = functions.get_vendor(request)

    all_jobs = models.ServiceLog.objects.filter(vendor_id=vendor, finished=True).all()

    if trigger:
        return redirect('root')

    try:
        redir = request.GET.get("redirect").replace("'","")
    except:
        redir = 'root'
    
    job_formated = functions.report_list(all_jobs)
    pass

def def_thing():
    pass