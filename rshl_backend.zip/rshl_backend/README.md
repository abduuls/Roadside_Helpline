# Roadside Help Line

needed
- Django
- django-crispy
- hasllib



setup:
```
pip install -r requirements.txt
```

```
python manage.py makemigrations vendor_rshl admin_rshl
``` 
or subsiquently 
```
python manage.py makemigrations
```

and then

```
python manage.py migrate
```

and for only once:
```
python manage.py createsuperuser
```
and follow along

run:
```
python manage.py runserver
```