import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def send_email(subject, text, html, recipients):
    username = "muniembutt114"
    password = "htsboteardfvepca"
    if (not username == "" or not username == None) and (not password == "" or not password == None):
        # sender = f"191400021@gift.edu.pk"
        # password = f"garygadgetguy199"
        # htsboteardfvepca
        sender = f"{username}@gmail.com"
        password = f"{password}"

        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = sender
        msg['To'] = ', '.join(recipients)

        part1 = MIMEText(text, 'plain')
        part2 = MIMEText(html, 'html')

        # Attach parts into message container.
        # According to RFC 2046, the last part of a multipart message, in this case
        # the HTML message, is best and preferred.
        msg.attach(part1)
        msg.attach(part2)

        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp_server:
            try:
                smtp_server.login(sender, password)
                smtp_server.sendmail(sender, recipients, msg.as_string())
                print("Message sent!")
            except Exception as e:
                print(e)

sub = "IDK"
text = "TEST"
html = "<h3>TEST<h3>"
recp = ["abdulwahab1345@gmail.com"]

send_email(sub,text,html,recp)